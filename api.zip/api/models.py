from django.db import models
from cloudinary.models import CloudinaryField
from markdownx.models import MarkdownxField
from django.utils.text import slugify
from urllib.parse import urlparse, parse_qs


class Car(models.Model):
    ENGINE_CHOICES = [
        ('petrol', 'Petrol'),
        ('diesel', 'Diesel'),
        ('electric', 'Electric'),
        ('hybrid', 'Hybrid'),
    ]
    GRADE_CHOICES = [
        ('6', '6'),
        ('5', '5'),
        ('4.5', '4.5'),
        ('4', '4'),
        ('3.5', '3.5'),
        ('3', '3'),
        ('R', 'R'),
    ]
    STATUS_CHOICES = [
        ('available', 'Available'),
        ('reserved', 'Reserved'),
        ('new', 'New'),
    ]
 
    # Required
    make = models.CharField(max_length=100)
    model = models.CharField(max_length=100)
    year = models.PositiveIntegerField()
 
    # Price range — use price_from as the base, price_to as upper limit
    price_from = models.DecimalField(max_digits=10, decimal_places=2)
    price_to = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
 
    # Optional
    name = models.CharField(max_length=100, blank=True, null=True)
    grade = models.CharField(max_length=3, choices=GRADE_CHOICES, blank=True, null=True)
    engine_type = models.CharField(max_length=10, choices=ENGINE_CHOICES, blank=True, null=True)
    mileage = models.PositiveIntegerField(blank=True, null=True)
    color = models.CharField(max_length=50, blank=True, null=True)
    transmission = models.CharField(max_length=50, blank=True, null=True)
    features = models.TextField(blank=True, null=True)
    description = MarkdownxField(blank=True, null=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='available')
    created_at = models.DateTimeField(auto_now_add=True)
 
    class Meta:
        verbose_name = "Car"
        verbose_name_plural = "Cars"
        ordering = ['-created_at']
 
    def __str__(self):
        return f"{self.make} {self.model} ({self.year})"
 
    def price_display(self):
        """Returns formatted price range string e.g. KES 954,000 - 1,500,000"""
        base = f"KES {int(self.price_from):,}"
        if self.price_to:
            return f"{base} - {int(self.price_to):,}"
        return base


class CarImage(models.Model):
    car = models.ForeignKey(Car, on_delete=models.CASCADE, related_name="images")
    image = CloudinaryField('image')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Car Image"
        verbose_name_plural = "Car Images"

    def __str__(self):
        return f"Image for {self.car.make} {self.car.model}"


class CarEnquiry(models.Model):
    BUDGET_CHOICES = [
        ('below_1m', 'Below Ksh 1M'),
        ('1m_2m', 'Ksh 1M - 2M'),
        ('2m_3m', 'Ksh 2M - 3M'),
        ('above_3m', 'Above Ksh 3M'),
    ]

    full_name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    vehicle_of_interest = models.CharField(max_length=100)
    budget_range = models.CharField(max_length=20, choices=BUDGET_CHOICES, default='below_1m')
    message = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Car Enquiry"
        verbose_name_plural = "Car Enquiries"
        ordering = ['-created_at']

    def __str__(self):
        return f"Car Enquiry from {self.full_name} about {self.vehicle_of_interest}"


class ContactEnquiry(models.Model):
    SUBJECT_TYPE_CHOICES = [
        ('general', 'General'),
        ('masterclass', 'Masterclass'),
        ('other', 'Other'),
    ]

    full_name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    subject_type = models.CharField(max_length=20, choices=SUBJECT_TYPE_CHOICES, default='general')
    subject = models.CharField(max_length=200, blank=True, null=True)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Contact Enquiry"
        verbose_name_plural = "Contact Enquiries"
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.get_subject_type_display()} enquiry from {self.full_name}"


class Testimonial(models.Model):
    DISPLAY_CHOICES = [
        ('text', 'Text Only'),
        ('video', 'Video Only'),
        ('both', 'Text + Video'),
    ]

    title = models.CharField(max_length=255, blank=True, null=True)
    slug = models.SlugField(max_length=255, unique=True, blank=True)
    author_name = models.CharField(max_length=150, blank=True, null=True)
    author_role = models.CharField(max_length=150, blank=True, null=True)
    testimonial_text = models.TextField(blank=True, null=True)
    youtube_url = models.URLField(blank=True, null=True)
    youtube_id = models.CharField(max_length=50, blank=True, null=True, editable=False)
    layout_type = models.CharField(max_length=10, choices=DISPLAY_CHOICES, default='text')
    rating = models.PositiveSmallIntegerField(default=5)
    featured = models.BooleanField(default=False)
    show_on_homepage = models.BooleanField(default=True)
    display_order = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['display_order', '-created_at']
        verbose_name = "Testimonial"
        verbose_name_plural = "Testimonials"

    def __str__(self):
        return f"{self.title} - {self.author_name or 'Anonymous'}"

    def extract_youtube_id(self):
        if not self.youtube_url:
            return None
        parsed = urlparse(self.youtube_url)
        if 'youtube' in parsed.netloc:
            return parse_qs(parsed.query).get('v', [None])[0]
        elif 'youtu.be' in parsed.netloc:
            return parsed.path.strip('/')
        return None

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.title) or "testimonial"
            slug_candidate = base_slug
            counter = 1
            while Testimonial.objects.filter(slug=slug_candidate).exists():
                slug_candidate = f"{base_slug}-{counter}"
                counter += 1
            self.slug = slug_candidate

        if self.youtube_url:
            self.youtube_id = self.extract_youtube_id()

        super().save(*args, **kwargs)

    def youtube_embed_url(self):
        return f"https://www.youtube.com/embed/{self.youtube_id}" if self.youtube_id else None